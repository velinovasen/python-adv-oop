#from SoftuniAdvanced.OOP.inheritance.mix_it.project.parking_mall.parking_mall import ParkingMall
from project.parking_mall.parking_mall import ParkingMall


class Level3(ParkingMall):

    def __init__(self):
        super(Level3, self).__init__(80)

